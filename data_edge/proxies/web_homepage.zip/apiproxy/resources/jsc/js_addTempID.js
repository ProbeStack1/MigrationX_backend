 var content = context.getVariable("request.content");

if ( typeof content !== "undefined" && content !== null && content !== "") {
    var payload = JSON.parse(content);
    
    if (payload !== null) {
        var tempid = context.getVariable("accesstoken.tempid");
        if (typeof tempid !== "undefined" && tempid !== null && tempid !== "") payload.tempid = tempid;
        context.setVariable("request.content", JSON.stringify(payload));
    }
}

print("The new payload is: \n" + JSON.stringify(payload,null,2));