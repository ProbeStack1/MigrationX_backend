var req= JSON.parse(context.getVariable("request.payload"));

var req_userid = context.getVariable("request.header.userid");
var path = context.getVariable("proxy.pathsuffix");



var valid_uid = [];
valid_uid = context.getVariable("private.validUserId");

var valid_uid_arr = valid_uid.split(',');
var mock = "false";

//Validating thr user id
for (i=0;i<valid_uid_arr.length; i++)
    {
        if(req_userid == valid_uid_arr[i]) {
            
            mock = "true";
        }
        
    }
    
context.setVariable("mock",mock);    
    
    if (mock == "true") {
        
        if (path == "/gethomepageinfo") {
            var json = context.getVariable("private.gethomepageinfo");
            
            // json = json.replace(/\//g, ",");
            // json = json.replace(/[[\]]/g,'');
        }
        json = json.replace(/\//g, ",");
        json = json.replace(/[[\]]/g,'');
    context.setVariable("respayload",json);
    }
    
