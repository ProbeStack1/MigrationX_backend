var content = context.getVariable("request.content");

if (typeof content !== "undefined" && content !== null && content !== "") {
    var payload = JSON.parse(content);
    
    if (payload !== null) {
        var uid = context.getVariable("accesstoken.uid");
        var upid = context.getVariable("accesstoken.upid");
        var subid = context.getVariable("accesstoken.subid");

        if (typeof uid !== "undefined" && uid !== null && uid !== "") payload.uid = uid;
        if (typeof upid !== "undefined" && upid !== null && upid !== "") payload.upid = upid;
        if (typeof subid !== "undefined" && subid !== null && subid !== "") payload.subid = subid;

        context.setVariable("request.content", JSON.stringify(payload));
    }
}

print("The new payload is: \n" + JSON.stringify(payload,null,2));