print( "Here is the Target URL:- " + context.getVariable("mytarget.path"));
print(context.getVariable("loadbalancing.targetserver"));
print(context.getVariable("target.host"));

print("TargetPath=" + context.getVariable("target.url"));

var rcode = context.getVariable("response.status.code");
context.setVariable("my.badRequest", false);

print ("body1\n " + body + ";\n result code= " + rcode);

if ( rcode == "200" ) {
    var body = context.getVariable("response.content");
    if ( typeof body !== "undefined" && body !== null && body !== "" ) {
        var pald = JSON.parse(body);
        if ( typeof pald !== "undefined" && pald !== null && pald !== "" ) {
            if ( pald.result < 0 ) {
                context.setVariable("myerror.content", context.getVariable("response.content"));
                context.setVariable("response.status.code", "400");
                context.setVariable("my.badResponse", true);
            }
            print ("result= " + pald.result);
        }
    }
}

