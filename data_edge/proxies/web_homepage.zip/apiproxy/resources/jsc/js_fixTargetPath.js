var pxppth = context.getVariable("proxy.pathsuffix");
var easyaccessTargetPath = context.getVariable("MemberAPI.EnvironmentProperties.targetEnvPath.easyaccess");
var easyaccessTargetPath_getfinancebalance = context.getVariable("EnvironmentProperties.targetEnvPath.easyaccess.getfinbalance");

context.setVariable("target.copy.pathsuffix", "false");
print("mytargetPath= " + pxppth);

var pathMap = {
	gethomepageinfo: "/web/homepage/gethomepageinfoservice/v1/gethomepageinfo",
	getfinancebalance: "/web/homepage/getfinancebalanceservice/v1/getfinancebalance",
	myaccountinfo: "/web/homepage/getaccountinfoservice/v1/getaccountinfo"
};

var cleanPxppth = pxppth.substring(1);
print("cleanPxppth***"+cleanPxppth);
print("pathMap***"+pathMap);

if (pathMap.hasOwnProperty(cleanPxppth) && cleanPxppth == "getfinancebalance"){
    context.setVariable("mytarget.path", easyaccessTargetPath_getfinancebalance + pathMap[cleanPxppth]);
} else if (pathMap.hasOwnProperty(cleanPxppth)) {
	context.setVariable("mytarget.path", easyaccessTargetPath + pathMap[cleanPxppth]);
} else {
	print ("INVALID PATH SUFFIX: " + pxppth);
}

/*if (pathMap.hasOwnProperty(cleanPxppth)) {
	context.setVariable("mytarget.path", easyaccessTargetPath + pathMap[cleanPxppth]);
} else if (pathMap.hasOwnProperty(cleanPxppth) && cleanPxppth == "getfinancebalance"){
    context.setVariable("mytarget.path", easyaccessTargetPath_getfinancebalance + pathMap[cleanPxppth]);
}else {
	print ("INVALID PATH SUFFIX: " + pxppth);
}*/

print( "Here is the Target URL:- " + context.getVariable("mytarget.path"));