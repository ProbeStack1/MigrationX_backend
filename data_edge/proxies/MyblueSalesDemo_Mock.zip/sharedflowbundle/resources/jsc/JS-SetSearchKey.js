var req = JSON.parse(context.getVariable("request.content"));

var networkId = req.networkId;
var geoLocation = req.geoLocation;
var searckKeyword = req.searchParameter;
var serk = searckKeyword.substring(0,3);
serk = serk.toLowerCase();
var keyword;
var targetHit;

//Logic to identify when to call backend
if(geoLocation == ""){
    keyword = "target";
}

switch(serk){
    case "eye":
        if(geoLocation == "42.11189171153843,-72.55033504487166"  && networkId == "311005002"){
            keyword = "eye exam";
        }
        else{
            keyword = "target";
            targetHit = "true";
        }
        break;
        
    case "beh":
        if(geoLocation == "42.11189171153843,-72.55033504487166"  && networkId == "311005002"){
            keyword = "behavioral health office visit";
        }
        else{
            keyword = "target";
            targetHit = "true";
        }
        break;
        
    case "hip":
        //keyword = "hip replacement - full";
        if(geoLocation == "42.11189171153843,-72.55033504487166"  && networkId == "311005002"){
            keyword = "hip replacement - full";
        }
        else{
            keyword = "target";
            targetHit = "true";
        }
        break;
        
    case "kne":
        //keyword = "knee replacement - full";
        if(geoLocation == "42.11189171153843,-72.55033504487166" && networkId == "311005016"){
            keyword = "knee replacement - full-springfield";
        }
        else{
            if(geoLocation == "42.74896907608691,-71.48558409782606" && networkId == "311005014"){
                keyword = "knee replacement - full-nashua";
            }
            else{
                keyword = "target";
                targetHit = "true";
            }
        }
        break;
        
    case "phy":
        if(geoLocation == "39.741133927125276,-104.97445367773273" && networkId == "311005002"){
            keyword = "physician office visit";
        }
        else{
            keyword = "target";
            targetHit = "true";
        }
        break;
        
    case "vag":
        //keyword = "vaginal delivery";
        if(geoLocation == "42.11189171153843,-72.55033504487166"  && networkId == "311005002"){
            keyword = "vaginal delivery";
        }
        else{
            keyword = "target";
            targetHit = "true";
        }
        break;
    // added 04/01 for mocking actual backend call
    default:
    print("in default block");
    keyword = "target";
    targetHit = "true";
}


print("searchKey: "+keyword);
context.setVariable("searchKey",keyword);
context.setVariable("targetHit",targetHit);

