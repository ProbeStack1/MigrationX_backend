// TODO: Implement case insensitive user verification in memberlogin page. 
var user = context.getVariable("useridin");

if(user) {
    user = user.toLowerCase();
    context.setVariable("useridin", user);    
}
