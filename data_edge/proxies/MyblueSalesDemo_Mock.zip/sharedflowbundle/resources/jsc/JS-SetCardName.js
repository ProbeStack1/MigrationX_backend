var req = JSON.parse(context.getVariable("request.content"));
var fileName = req.memberCards[0].fileName;
fileName = fileName.toLowerCase();
//print("Initial FileName :"+fileName);

var fName = fileName.split("_");
//print("Length :"+fName.length);
var cardFileName = '';
if(fName.length > 2){
    cardFileName = fName[1]+"_"+fName[2];
}
else{
    cardFileName = fileName;
}
//print("Final FileName :"+cardFileName);
context.setVariable("cardImageKey",cardFileName);
