var userId = context.getVariable("useridin");
var req = JSON.parse(context.getVariable("request.content"));

var networkId = req.networkId;

//var professionalKvmKey = userId+"_"+networkId;
var professionalKvmKey = "fad_professional_"+networkId;
context.setVariable("professionalKvmKey",professionalKvmKey);
//print("professionalKvmKey :"+professionalKvmKey);