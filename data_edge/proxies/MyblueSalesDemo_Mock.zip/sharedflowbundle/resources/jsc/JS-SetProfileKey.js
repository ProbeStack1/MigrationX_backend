//var userId = context.getVariable("useridin"); FAD response will remain same for all users.
var userId = "fad_profile";
var req = JSON.parse(context.getVariable("request.content"));

var networkId = req.networkId;
var procedureId = req.procedureId;

if(req.hasOwnProperty('procedureId')){
    var profileKvmKey = userId+"_"+networkId+"_"+procedureId;
    context.setVariable("profileKvmKey",profileKvmKey);
}
else{
    var profileKvmKey = userId+"_doctor_facility";
    context.setVariable("profileKvmKey",profileKvmKey);
}
