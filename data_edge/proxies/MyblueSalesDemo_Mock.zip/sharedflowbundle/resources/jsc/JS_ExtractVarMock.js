var req= JSON.parse(context.getVariable("request.payload"));
var req_userid = context.getVariable("useridin");
if (req_userid) {
    req_userid = req_userid.toLowerCase();
}

var path = context.getVariable("proxy.pathsuffix");
var basepath = context.getVariable("proxy.basepath");

var valid_uid = [];

var mock = "false";
var json = '';
var targetHit = "true";
if(path != "/logout"){
    valid_uid = context.getVariable("private.validUserId");
    valid_uid = valid_uid.toLowerCase();
    var valid_uid_arr = valid_uid.split(',');
    //Validating the user id
    for (i=0;i<valid_uid_arr.length; i++)
        {
            if(req_userid == valid_uid_arr[i]) {
                mock = "true";
            }
        }
}
else{
    mock = "true";
}

if(path == "/citysearch" || path == "/autocomplete" || path == "/imagetopdf"){
    mock = "true";
}

if(path == "/getmemprofile" &&  basepath == "/member/web/v2/profile"){
    path = "/getmemprofilev2";
}
// to accommodate memberlogin v1 and v2. The login kvm contains response for both. Changes as part of June sync-up 07/05
if(path == "/memberlogin" &&  basepath == "/member/web/v2/access"){
    path = "/memberloginv2";
    print('in /mem and v2');
}

var initialIndex;

    if (mock == "true") {
        path = path.replace("/","");
        var kvmRes = context.getVariable("private.kvmResponse");
        //print("kvmRes = "+ kvmRes);
        kvmRes = kvmRes.replace(/~/g,",");
        kvmRes = JSON.parse(kvmRes);
        print(kvmRes);
        kvmRes = kvmRes.apiResponses;
        var index = -1;
        var specialOpr = "false";
        for(var x in kvmRes){
            var ent = kvmRes[x];
            if(ent.apiName == path){
                json = ent.apiResponse;
                initialIndex = x;
                //print("Response");
                //print(json);
                if(path == "getclaimdetails"){
                    specialOpr = "true";
                    var claimReq = JSON.parse(context.getVariable("request.content"));
                    var claimId = claimReq.claimId;
                    if((claimId == ent.apiResponse.claimId) || (parseInt(claimId,10) == ent.apiResponse.claimId)){
                        index = x;
                    }
                }
                if(path == "getbrandclaimssummary"){
                    specialOpr = "true";
                    var claimReq = JSON.parse(context.getVariable("request.content"));
                    var reqYear = claimReq.filterCriteria.value;
                    if(ent.apiResponse.claimsSummary[0] != undefined){
                        var resDate = ent.apiResponse.claimsSummary[0].dateOfService;
                        resDate = resDate.split("-");
                        var resYear = resDate[0];
                        if(reqYear == resYear){
                            index = x;
                        }
                    }
                }
                
                if(path == "getclaimprocessingstatus"){
                    specialOpr = "true";
                    var claimReq = JSON.parse(context.getVariable("request.content"));
                    var claimId = claimReq.claimId;
                    if(ent.apiResponse.statusRecord){
                        if((claimId == ent.apiResponse.statusRecord.claimId) || (parseInt(claimId,10) == ent.apiResponse.statusRecord.claimId)){
                            index = x;
                        }
                    }
                }
                
                if(path == "getrxdetails"){
                    specialOpr = "true";
                    var Req = JSON.parse(context.getVariable("request.content"));
                    var mDate = Req.rxIncurredDate;
                    if(mDate == ent.apiResponse.rxDetails.lastFill){
                        index = x;
                    }
                }
                if(path == "gettaxforms"){
                    specialOpr = "true";
                    var Req = JSON.parse(context.getVariable("request.content"));
                    var reqYear = Req.year;
                    if(reqYear == ent.apiResponse.forms[0].year){
                        index = x;
                    }
                }
                if(path == "citysearch"){
                    specialOpr = "true";
                    var reqPlace = context.getVariable("request.queryparam.place");
                    print("reqPlace"+reqPlace);
                    if(reqPlace === null || reqPlace == "null"){
                       
                        var city = context.getVariable("request.queryparam.city");
                        if(city === null || city == "null"){
                            targetHit = "true";
                        }
                        else{
                            city = city.toLowerCase();
                            reqPlace = city;
                        }
                        
                    }
                    
                    if(reqPlace == ent.apiResponse.searchParameter){
                        index = x;
                    }
                    
                    
                }
                if(path == "autocomplete"){
                    specialOpr = "true";
                    var Req = JSON.parse(context.getVariable("request.content"));
                    var reqSearchKey = Req.searchParameter;
                    reqSearchKey = reqSearchKey.toLowerCase();
                    if(reqSearchKey == ent.apiResponse.searchParameter){
                        index = x;
                    }
                }
                if(path == "searchbyproviders"){
                    specialOpr = "true";
                    var Req = JSON.parse(context.getVariable("request.content"));
                    var proId = Req.procedureId;
                    var geoLc = Req.geoLocation;
                    var netId = Req.networkId;
                    if(proId == ent.procedureId && geoLc == ent.geoLocation && netId == ent.networkId){
                        index = x;
                    }
                }
                if(path == "professionalprofile"){
                    specialOpr = "true";
                    var Req = JSON.parse(context.getVariable("request.content"));
                    var locId = Req.locationId;
                    if(locId == ent.apiResponse.matchedLocation){
                        index = x;
                    }
                }
                if(path == "facilityprofile"){
                    specialOpr = "true";
                    var Req = JSON.parse(context.getVariable("request.content"));
                    if(Req.hasOwnProperty('procedureId')){
                        var locId = Req.locationId;
                        if(locId == ent.apiResponse.facility.matchedLocation){
                            index = x;
                        }
                    }
                    else{
                        var facId = Req.facilityId;
                        var resFacId = ent.apiResponse.facility.providerId;
                        resFacId = resFacId.substring(1);
                        if(facId == resFacId){
                            index = x;
                        }
                    }
                    
                }
                if(path == "searchbyprofessional"){
                    specialOpr = "true";
                    var Req = JSON.parse(context.getVariable("request.content"));
                    var locId = Req.locationId;
                    var netId = Req.networkId;
                    if(locId == ent.apiResponse.pdfRequest.searchParams.locationId && netId == ent.apiResponse.pdfRequest.searchParams.networkId){
                        index = x;
                    }
                }
                
                if(path == "getvisitdetails"){
                    specialOpr = "true";
                    var Req = JSON.parse(context.getVariable("request.content"));
                    var pNumber = Req.providerNumber;
                    if(pNumber == ent.apiResponse.visitDetails.providerNumber){
                        index = x;
                    }
                }
                
                if(path == "getplansbenefitsservices"){
                    specialOpr = "true";
                    var Req = JSON.parse(context.getVariable("request.content"));
                    var reqPlan = Req.planName;
                    if(reqPlan == ent.apiResponse.planName){
                        index = x;
                    }
                }
                
                if(path == "getsubscribercert"){
                    specialOpr = "true";
                    var Req = JSON.parse(context.getVariable("request.content"));
                    var reqPlanArr = Req.planName.split(" ");
                    var reqPlan = reqPlanArr[0];
                    var ecoPolicy = ent.apiResponse.RowSet.eocPolicies;
                    for(var z in ecoPolicy){
                        var arrResp = ecoPolicy[z].policyFormName.split(" ");
                        var Resp = arrResp[0];
                        if(reqPlan == Resp){
                            //print("found");
                            index = x;
                        }
                    }
                }
            }
            
        }
        //print("Final Index :"+index);
        if(specialOpr == "true" ){
            if(index > -1){
                json = kvmRes[index].apiResponse;
                targetHit = "false";
            }
            else{
                if((path == "getvisitdetails") || (path == "getsubscribercert") || (path == "getbrandclaimssummary") || (path == "getclaimdetails") || (path == "getclaimprocessingstatus")){
                    //print("In default response");
                    //json = {"visitDetails":{"lastDateOfService":"2021-02-28","hasAddress":true,"addressStr":"759 CHESTNUT ST, SPRINGFIELD, MA, 01199","claimId":"026210110045400","providerPhone":"413-794-3233","providerNumber":"70010000J21564","providerType":"PHYSICIAN","providerName":"KATHLEEN A KERRIGAN MD","memberFirstName":"DAVID","memberLastName":"DOWD","memberMiddleInitial":"","memberId":"051002665000000","subscriberId":"0510026650000","providerSpeciality":"INTERNAL MEDICINE","dateOfService":"2021-02-28","isAllowedChangePCP":true,"isPCP":false,"isRequiredPCP":true,"pcpId":"70010000J21564","docVisitHistory":[{"date":"2021-02-28","claimNumber":"026210110045400"}]}};
                    json = kvmRes[initialIndex].apiResponse;
                    
                    if(path == "getbrandclaimssummary"){
                        json = {"queryCriteria":{"hasMoreRecords":false,"totalRecordCount":0,"scroll":{"recordStartIndex":0,"recordEndIndex":0}},"claimsSummary":[]};
                    }
                }
                else{
                    json = {};
                    mock = "false";
                }
            }
        }
        
        if((path == "citysearch") && (index > -1)){
            json = {"cities":json.cities};
            var reqPlace = context.getVariable("request.queryparam.place");
            if(reqPlace === null || reqPlace == "null"){
                var city = context.getVariable("request.queryparam.city");
                var state = context.getVariable("request.queryparam.state_code");
                var zip = context.getVariable("request.queryparam.zip");
                var cities = json.cities;
                var cityIndex;
                for(var x in cities){
                    if(city == cities[x].city && state == cities[x].state_code && zip == cities[x].zip){
                        cityIndex = x;
                    }
                }
                json = {"cities":[json.cities[cityIndex]]};
            }      
                    
        }
        
        context.setVariable("mock",mock); 
        context.setVariable("respayload",JSON.stringify(json));
        context.setVariable("targetHit",targetHit);
        //if targetHit = 1, that means we need to call the actual target.
    }
    else {
        var errorMsg = {"error": "API not found"};
        context.setVariable("respayload",errorMsg);
    }
