   
  var proxyPath = (context.getVariable("proxy.pathsuffix")).replace(/\//g,"");
  context.setVariable("proxyPath", proxyPath);