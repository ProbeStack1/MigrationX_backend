 var apiname = context.getVariable("proxy.pathsuffix");
 apiname = apiname.replace(/\//g,"");
 var apihourcountname = apiname + "HourCount";
context.setVariable("apiname",apiname);

var hourminname = apiname + "hourmin";
  context.setVariable("hourminname", hourminname);
 
