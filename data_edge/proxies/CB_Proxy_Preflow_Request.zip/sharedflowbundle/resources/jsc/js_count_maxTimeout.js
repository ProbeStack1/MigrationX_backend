 var apiName1 = context.getVariable("proxy.pathsuffix");
 var apiName = apiName1.replace(/\//g,"");
 print("apiName***"+apiName);
 context.setVariable("apiName",apiName);
 
 var test = context.getVariable("pxppth1");
context.setVariable("mytarget.path",context.getVariable("mytarget.path"));

 var maxLimit=3;
 var storageName='failed_response';
 var valueToBeParsed;
 var apiTimeout = null;
 var timeoutAPI = context.getVariable("timeoutAPI0");
 var timeout = null;
 if (timeoutAPI !== null){
  timeout=(JSON.parse(JSON.stringify(timeoutAPI))).split(","); 
  print ("res4****"+timeout[1]);
  print ("res5****"+timeout[0]); 
 }

 if (timeout !==null && timeout[1] >= maxLimit ){
     
    apiTimeout = timeout[0];
    context.setVariable('failedProxy',apiTimeout);
 }
