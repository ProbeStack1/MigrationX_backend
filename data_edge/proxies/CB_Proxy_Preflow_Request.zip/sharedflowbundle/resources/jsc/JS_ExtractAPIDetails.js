    var CBDate = context.getVariable("CBDate");
    var override = "true";
    var countapi = context.getVariable("Count");
    var hourmin = context.getVariable("hourmincache");
    var kvm = context.getVariable("private.CBDaily");
    var apiname = context.getVariable("proxy.pathsuffix");
    var targetdetails = context.getVariable("targetdetails");
 
     var targetendtime = "";
     var targetstarttime ="";
     var apiendtime = "";
     var reason = "";
     var systime = "";
     
 if (targetdetails !== null || targetdetails !== "") {
     targetdetails = targetdetails.toString();
     targetdetailsarr =targetdetails.split(',');
     var targetendtime = targetdetailsarr[0];
     var targetstarttime =targetdetailsarr[1];
     var apiendtime = targetdetailsarr[2];
     var reason = targetdetailsarr[3];
     var systime = targetdetailsarr[4];
     
 }
 
 if (CBDate === systime) {
     override = "false";
 }
 var restime = targetendtime - targetstarttime;
 
 if (reason === "" || reason ===null) {
     reason = "Timeout";
 }
 var apitime = targetendtime - apiendtime;
 
 context.setVariable("Kvm",kvm);
 
 
 apiname = apiname.replace(/\//g,"");
 var apinamesuffix = apiname +"_" + hourmin + ", Count :"; //memberlogin_1,Count :
     
context.setVariable("apiname",apiname);

countapi++;
 
 context.setVariable("NameSuffix1",apinamesuffix);
  if (override === true || override === "true") {
     kvm = "";
     context.setVariable("CBDate",systime);
     
 }
if (kvm !== "" && kvm !== null) {
   var index = kvm.indexOf(apinamesuffix); 
    }
 
 if (override === true || override === "true") {
     kvm = "";
     
 }
 
 if (kvm === "" || kvm === null )
 {
     countapi = 1;
     var index = 0;
 }
 
 if (index === 0 || index === -1) {countapi = 1;}
 context.setVariable("index",index);
 
if(countapi >1) { //updating only count value
    if (index !== -1 && index > 0) {
        arr = kvm.split(apinamesuffix);
        
        context.setVariable("arr1",arr[1]);
        var arry =arr[1].toString();
        arry=arry.substr(1);
        context.setVariable("arry",arry);

        if (arr[0] !== "" && arr[0] !== null) 
         { var apidetails =  arr[0] + apinamesuffix +  countapi + arry ; }
         else  { { var apidetails =  apinamesuffix + countapi + arry ;  } }
    } else {countapi == 1;} 
}

 if (countapi == 1) { // update the first occurence within a specific perid of time
    
        var apidetails ="[" + apinamesuffix + countapi + " ,  Target Response Time : "  + restime + "ms , API time : " + apitime + "ms , Circuit Trip Time : "+ systime + " , Reason : " + reason + "]" ;
        if (kvm !== "" && kvm !== null) {
            apidetails = apidetails + "," + kvm;
        }
}
context.setVariable("Count",countapi);
context.setVariable("HourMin",hourmin);
context.setVariable("apidetails",apidetails);
/*
context.setVariable("Count","0");
context.setVariable("HourMin","");
context.setVariable("apidetails","");*/